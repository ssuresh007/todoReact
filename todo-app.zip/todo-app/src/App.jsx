import { useEffect, useMemo, useState } from 'react'
import './App.css'

const API_BASE = import.meta.env.VITE_API_BASE ?? 'http://localhost:8000'

const readToken = () => localStorage.getItem('todo_token')

function App() {
  const [token, setToken] = useState(readToken)
  const [user, setUser] = useState(null)
  const [todos, setTodos] = useState([])
  const [text, setText] = useState('')
  const [filter, setFilter] = useState('all')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')

  const [authMode, setAuthMode] = useState('login')
  const [authForm, setAuthForm] = useState({
    name: '',
    email: '',
    password: '',
    confirm: '',
    token: '',
  })
  const [authError, setAuthError] = useState('')
  const [authNotice, setAuthNotice] = useState('')
  const [authLoading, setAuthLoading] = useState(false)

  const setStoredToken = (nextToken) => {
    if (nextToken) {
      localStorage.setItem('todo_token', nextToken)
      setToken(nextToken)
    } else {
      localStorage.removeItem('todo_token')
      setToken(null)
    }
  }

  const authFetch = async (url, options = {}) => {
    const response = await fetch(url, {
      ...options,
      headers: {
        ...(options.headers ?? {}),
        Authorization: `Bearer ${token}`,
      },
    })

    if (response.status === 401) {
      setStoredToken(null)
      setUser(null)
      setTodos([])
      throw new Error('Session expired. Please login again.')
    }

    return response
  }

  const loadTodos = async () => {
    if (!token) return
    setIsLoading(true)
    setError('')

    try {
      const [todosResponse, userResponse] = await Promise.all([
        authFetch(`${API_BASE}/api/todos`),
        authFetch(`${API_BASE}/api/auth/me`),
      ])

      if (!todosResponse.ok) {
        throw new Error('Failed to load todos.')
      }
      if (userResponse.ok) {
        const userData = await userResponse.json()
        setUser(userData)
      }

      const data = await todosResponse.json()
      setTodos(data)
    } catch (err) {
      setError(err.message ?? 'Could not load todos.')
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    loadTodos()
  }, [token])

  const remaining = useMemo(
    () => todos.filter((todo) => !todo.done).length,
    [todos]
  )

  const visibleTodos = useMemo(() => {
    if (filter === 'active') {
      return todos.filter((todo) => !todo.done)
    }
    if (filter === 'completed') {
      return todos.filter((todo) => todo.done)
    }
    return todos
  }, [filter, todos])

  const handleAuthChange = (field) => (event) => {
    setAuthForm((prev) => ({
      ...prev,
      [field]: event.target.value,
    }))
  }

  const setMode = (mode) => {
    setAuthMode(mode)
    setAuthError('')
    setAuthNotice('')
  }

  const handleAuthSubmit = async (event) => {
    event.preventDefault()
    setAuthError('')
    setAuthNotice('')
    setAuthLoading(true)

    try {
      const payload =
        authMode === 'register'
          ? {
              name: authForm.name.trim(),
              email: authForm.email.trim(),
              password: authForm.password,
              password_confirmation: authForm.confirm,
            }
          : {
              email: authForm.email.trim(),
              password: authForm.password,
            }

      const response = await fetch(
        `${API_BASE}/api/auth/${authMode === 'register' ? 'register' : 'login'}`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Accept: 'application/json',
          },
          body: JSON.stringify(payload),
        }
      )

      const data = await response.json()
      if (!response.ok) {
        throw new Error(data.message ?? 'Authentication failed.')
      }

      setStoredToken(data.token)
      setUser(data.user)
      setAuthForm({ name: '', email: '', password: '', confirm: '', token: '' })
    } catch (err) {
      setAuthError(err.message ?? 'Authentication failed.')
    } finally {
      setAuthLoading(false)
    }
  }

  const handleForgotSubmit = async (event) => {
    event.preventDefault()
    setAuthError('')
    setAuthNotice('')
    setAuthLoading(true)

    try {
      const response = await fetch(`${API_BASE}/api/auth/forgot-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({ email: authForm.email.trim() }),
      })

      const contentType = response.headers.get('content-type') ?? ''
      const data = contentType.includes('application/json')
        ? await response.json()
        : { message: await response.text() }
      if (!response.ok) {
        throw new Error(data.message ?? 'Request failed.')
      }

      setAuthNotice(
        'Reset link sent. Check the API logs for the token in local development.'
      )
      setMode('reset')
    } catch (err) {
      setAuthError(err.message ?? 'Request failed.')
    } finally {
      setAuthLoading(false)
    }
  }

  const handleResetSubmit = async (event) => {
    event.preventDefault()
    setAuthError('')
    setAuthNotice('')
    setAuthLoading(true)

    try {
      const response = await fetch(`${API_BASE}/api/auth/reset-password`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          Accept: 'application/json',
        },
        body: JSON.stringify({
          email: authForm.email.trim(),
          token: authForm.token.trim(),
          password: authForm.password,
          password_confirmation: authForm.confirm,
        }),
      })

      const contentType = response.headers.get('content-type') ?? ''
      const data = contentType.includes('application/json')
        ? await response.json()
        : { message: await response.text() }
      if (!response.ok) {
        throw new Error(data.message ?? 'Reset failed.')
      }

      setAuthNotice('Password updated. Please login.')
      setMode('login')
      setAuthForm({ name: '', email: '', password: '', confirm: '', token: '' })
    } catch (err) {
      setAuthError(err.message ?? 'Reset failed.')
    } finally {
      setAuthLoading(false)
    }
  }

  const handleLogout = async () => {
    setError('')
    try {
      await authFetch(`${API_BASE}/api/auth/logout`, { method: 'POST' })
    } catch (err) {
      setError(err.message ?? 'Logout failed.')
    } finally {
      setStoredToken(null)
      setUser(null)
      setTodos([])
    }
  }

  const handleSubmit = async (event) => {
    event.preventDefault()
    const trimmed = text.trim()
    if (!trimmed) return

    setError('')

    try {
      const response = await authFetch(`${API_BASE}/api/todos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: trimmed }),
      })

      if (!response.ok) {
        throw new Error('Failed to save todo.')
      }

      const created = await response.json()
      setTodos((prev) => [created, ...prev])
      setText('')
    } catch (err) {
      setError(err.message ?? 'Could not save the todo.')
    }
  }

  const toggleTodo = async (id) => {
    const target = todos.find((todo) => todo.id === id)
    if (!target) return

    setError('')

    try {
      const response = await authFetch(`${API_BASE}/api/todos/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ done: !target.done }),
      })

      if (!response.ok) {
        throw new Error('Failed to update todo.')
      }

      const updated = await response.json()
      setTodos((prev) =>
        prev.map((todo) => (todo.id === id ? updated : todo))
      )
    } catch (err) {
      setError(err.message ?? 'Could not update the todo.')
    }
  }

  const removeTodo = async (id) => {
    setError('')

    try {
      const response = await authFetch(`${API_BASE}/api/todos/${id}`, {
        method: 'DELETE',
      })

      if (!response.ok) {
        throw new Error('Failed to delete todo.')
      }

      setTodos((prev) => prev.filter((todo) => todo.id !== id))
    } catch (err) {
      setError(err.message ?? 'Could not delete the todo.')
    }
  }

  const clearCompleted = async () => {
    const completed = todos.filter((todo) => todo.done)
    if (completed.length === 0) return

    setError('')

    try {
      await Promise.all(
        completed.map((todo) =>
          authFetch(`${API_BASE}/api/todos/${todo.id}`, { method: 'DELETE' })
        )
      )
      setTodos((prev) => prev.filter((todo) => !todo.done))
    } catch (err) {
      setError(err.message ?? 'Could not clear completed todos.')
    }
  }

  const formatDateTime = (value) => {
    if (!value) return '--'
    const date = new Date(value)
    if (Number.isNaN(date.getTime())) return '--'
    return new Intl.DateTimeFormat(undefined, {
      dateStyle: 'medium',
      timeStyle: 'short',
    }).format(date)
  }

  if (!token) {
    return (
      <div className="page">
        <main className="todo-app auth">
          <header className="todo-header">
            <div>
              <p className="eyebrow">Welcome</p>
              <h1>Todo List</h1>
              <p className="subtitle">Sign in to access your tasks.</p>
            </div>
          </header>

          {(authMode === 'login' || authMode === 'register') && (
            <div className="auth-switch">
              <button
                type="button"
                className={authMode === 'login' ? 'active' : ''}
                onClick={() => setMode('login')}
              >
                Login
              </button>
              <button
                type="button"
                className={authMode === 'register' ? 'active' : ''}
                onClick={() => setMode('register')}
              >
                Register
              </button>
            </div>
          )}

          {(authMode === 'login' || authMode === 'register') && (
            <form className="auth-form" onSubmit={handleAuthSubmit}>
              {authMode === 'register' ? (
                <input
                  type="text"
                  placeholder="Name"
                  value={authForm.name}
                  onChange={handleAuthChange('name')}
                  required
                />
              ) : null}
              <input
                type="email"
                placeholder="Email"
                value={authForm.email}
                onChange={handleAuthChange('email')}
                required
              />
              <input
                type="password"
                placeholder="Password"
                value={authForm.password}
                onChange={handleAuthChange('password')}
                required
              />
              {authMode === 'register' ? (
                <input
                  type="password"
                  placeholder="Confirm password"
                  value={authForm.confirm}
                  onChange={handleAuthChange('confirm')}
                  required
                />
              ) : null}
              <button type="submit" disabled={authLoading}>
                {authLoading
                  ? 'Please wait...'
                  : authMode === 'register'
                  ? 'Create account'
                  : 'Login'}
              </button>
            </form>
          )}

          {authMode === 'forgot' && (
            <form className="auth-form" onSubmit={handleForgotSubmit}>
              <input
                type="email"
                placeholder="Email"
                value={authForm.email}
                onChange={handleAuthChange('email')}
                required
              />
              <button type="submit" disabled={authLoading}>
                {authLoading ? 'Please wait...' : 'Send reset link'}
              </button>
            </form>
          )}

          {authMode === 'reset' && (
            <form className="auth-form" onSubmit={handleResetSubmit}>
              <input
                type="email"
                placeholder="Email"
                value={authForm.email}
                onChange={handleAuthChange('email')}
                required
              />
              <input
                type="text"
                placeholder="Reset token"
                value={authForm.token}
                onChange={handleAuthChange('token')}
                required
              />
              <input
                type="password"
                placeholder="New password"
                value={authForm.password}
                onChange={handleAuthChange('password')}
                required
              />
              <input
                type="password"
                placeholder="Confirm new password"
                value={authForm.confirm}
                onChange={handleAuthChange('confirm')}
                required
              />
              <button type="submit" disabled={authLoading}>
                {authLoading ? 'Please wait...' : 'Reset password'}
              </button>
            </form>
          )}

          {authMode === 'login' && (
            <button
              type="button"
              className="link-button"
              onClick={() => setMode('forgot')}
            >
              Forgot password?
            </button>
          )}

          {authMode === 'forgot' && (
            <button
              type="button"
              className="link-button"
              onClick={() => setMode('login')}
            >
              Back to login
            </button>
          )}

          {authMode === 'reset' && (
            <button
              type="button"
              className="link-button"
              onClick={() => setMode('login')}
            >
              Back to login
            </button>
          )}

          {authNotice ? <p className="notice">{authNotice}</p> : null}
          {authError ? <p className="error">{authError}</p> : null}
        </main>
      </div>
    )
  }

  return (
    <div className="page">
      <main className="todo-app">
        <header className="todo-header">
          <div>
            <p className="eyebrow">Daily Focus</p>
            <h1>Todo List</h1>
            <p className="subtitle">
              Capture tasks, keep momentum, and ship the important stuff.
            </p>
          </div>
          <div className="progress">
            <span>{remaining}</span>
            <span className="progress-label">tasks left</span>
          </div>
        </header>

        <div className="auth-bar">
          <span>Signed in as {user?.email ?? 'unknown'}</span>
          <button type="button" className="ghost" onClick={handleLogout}>
            Logout
          </button>
        </div>

        <form className="todo-form" onSubmit={handleSubmit}>
          <input
            type="text"
            value={text}
            onChange={(event) => setText(event.target.value)}
            placeholder="Add a task and press Enter"
            aria-label="New todo"
            disabled={isLoading}
          />
          <button type="submit" disabled={isLoading}>
            Add
          </button>
        </form>

        {error ? <p className="error">{error}</p> : null}

        <section className="todo-controls">
          <div className="filters">
            <button
              type="button"
              className={filter === 'all' ? 'active' : ''}
              onClick={() => setFilter('all')}
            >
              All
            </button>
            <button
              type="button"
              className={filter === 'active' ? 'active' : ''}
              onClick={() => setFilter('active')}
            >
              Active
            </button>
            <button
              type="button"
              className={filter === 'completed' ? 'active' : ''}
              onClick={() => setFilter('completed')}
            >
              Completed
            </button>
          </div>
          <button type="button" className="ghost" onClick={clearCompleted}>
            Clear completed
          </button>
        </section>

        <ul className="todo-list">
          {isLoading ? (
            <li className="empty">
              <span>Loading tasks...</span>
            </li>
          ) : visibleTodos.length === 0 ? (
            <li className="empty">
              <span>No tasks here yet.</span>
            </li>
          ) : (
            visibleTodos.map((todo) => (
              <li key={todo.id} className={todo.done ? 'done' : ''}>
                <label>
                  <input
                    type="checkbox"
                    checked={todo.done}
                    onChange={() => toggleTodo(todo.id)}
                  />
                  <span className="todo-text">
                    <span>{todo.text}</span>
                    <span className="todo-meta">
                      <span>Created: {formatDateTime(todo.created_at)}</span>
                      {todo.done ? (
                        <span>
                          Completed: {formatDateTime(todo.completed_at)}
                        </span>
                      ) : null}
                    </span>
                  </span>
                </label>
                <button
                  type="button"
                  className="icon"
                  onClick={() => removeTodo(todo.id)}
                  aria-label={`Delete ${todo.text}`}
                >
                  X
                </button>
              </li>
            ))
          )}
        </ul>
      </main>
    </div>
  )
}

export default App
