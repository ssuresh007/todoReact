<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});

Route::get('/reset-password/{token}', function (string $token) {
    return response()->json([
        'message' => 'Use the app to reset your password.',
        'token' => $token,
    ]);
})->name('password.reset');
