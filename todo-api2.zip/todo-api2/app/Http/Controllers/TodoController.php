<?php

namespace App\Http\Controllers;

use App\Models\Todo;
use Illuminate\Http\Request;

class TodoController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        return $request->user()
            ->todos()
            ->orderByDesc('created_at')
            ->get();
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $validated = $request->validate([
            'text' => ['required', 'string', 'max:255'],
        ]);

        $todo = Todo::create([
            'user_id' => $request->user()->id,
            'text' => $validated['text'],
            'done' => false,
        ]);

        return response()->json($todo, 201);
    }

    /**
     * Display the specified resource.
     */
    public function show(Todo $todo)
    {
        if ($todo->user_id !== request()->user()->id) {
            abort(404);
        }

        return $todo;
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, Todo $todo)
    {
        if ($todo->user_id !== $request->user()->id) {
            abort(404);
        }

        $validated = $request->validate([
            'text' => ['sometimes', 'required', 'string', 'max:255'],
            'done' => ['sometimes', 'required', 'boolean'],
        ]);

        if (array_key_exists('done', $validated)) {
            $validated['completed_at'] = $validated['done'] ? now() : null;
        }

        $todo->update($validated);

        return $todo;
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Todo $todo)
    {
        if ($todo->user_id !== request()->user()->id) {
            abort(404);
        }

        $todo->delete();

        return response()->noContent();
    }
}
